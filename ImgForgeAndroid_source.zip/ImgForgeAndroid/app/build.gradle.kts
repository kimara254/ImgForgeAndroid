plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.boldweararts.imgforge"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.boldweararts.imgforge"
        minSdk = 26
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
