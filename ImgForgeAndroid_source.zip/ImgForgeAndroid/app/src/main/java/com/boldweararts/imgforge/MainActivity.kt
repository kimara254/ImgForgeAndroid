package com.boldweararts.imgforge

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val pickImagesCode = 7102
    private lateinit var presetSpinner: Spinner
    private lateinit var selectedText: TextView
    private lateinit var statusText: TextView
    private lateinit var runButton: Button
    private var selectedUris: List<Uri> = emptyList()
    private var busy = false

    private data class Preset(
        val title: String,
        val description: String,
        val longEdge: Int? = null,
        val format: String,
        val dpi: Int? = null,
        val quality: Int? = null,
        val flatten: Boolean = false,
        val background: String? = null,
        val filter: String = "Lanczos",
        val timeout: Int = 900
    )

    private val presets = listOf(
        Preset("Fine Art Print · 8K PNG", "8000 px long edge · PNG · 300 DPI metadata · preserves alpha", 8000, "png", dpi = 300),
        Preset("Fine Art Master · 16K TIFF", "16000 px long edge · TIFF · 300 DPI metadata · large files", 16000, "tiff", dpi = 300, timeout = 1800),
        Preset("Transparent Streetwear PNG", "6000 px long edge · PNG · keeps existing transparency; does not remove backgrounds", 6000, "png", dpi = 300),
        Preset("Print TIFF · Keep Dimensions", "TIFF conversion without resizing · 300 DPI metadata", null, "tiff", dpi = 300),
        Preset("JPEG Preview", "3000 px long edge · JPEG quality 95 · transparent areas become white", 3000, "jpeg", quality = 95, flatten = true, background = "white"),
        Preset("WebP Preview", "3000 px long edge · WebP quality 92", 3000, "webp", quality = 92)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 248, 252))
            setPadding(dp(20), dp(22), dp(20), dp(20))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(18))
        }
        val title = TextView(this).apply {
            text = "ImgForge"
            textSize = 30f
            setTextColor(Color.rgb(16, 24, 40))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        content.addView(title)
        content.addView(text("Fine-art and streetwear image processing", 15f, Color.rgb(71, 84, 103)), margin(0, 4, 0, 18))

        val warning = TextView(this).apply {
            text = "PROCESSING ENGINE: Termux + ImageMagick + ImgForge 2.0\nOriginal images are copied into a separate input folder. Outputs are written separately."
            textSize = 13f
            setTextColor(Color.rgb(52, 64, 84))
            setBackgroundColor(Color.rgb(232, 238, 250))
            setPadding(dp(13), dp(12), dp(13), dp(12))
        }
        content.addView(warning, margin(0, 0, 0, 20))

        content.addView(section("1 · Select artwork"), margin(0, 0, 0, 8))
        val pickButton = button("Choose images", false)
        pickButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }
            startActivityForResult(intent, pickImagesCode)
        }
        content.addView(pickButton, margin(0, 0, 0, 8))
        selectedText = text("No images selected", 14f, Color.rgb(71, 84, 103))
        content.addView(selectedText, margin(0, 0, 0, 20))

        content.addView(section("2 · Choose a processing rule"), margin(0, 0, 0, 8))
        presetSpinner = Spinner(this)
        presetSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, presets.map { it.title })
        presetSpinner.setBackgroundColor(Color.WHITE)
        content.addView(presetSpinner, margin(0, 0, 0, 8))
        val presetInfo = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(71, 84, 103))
            setPadding(dp(2), dp(5), dp(2), dp(12))
        }
        content.addView(presetInfo)
        presetSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                presetInfo.text = presets[position].description
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        content.addView(section("3 · Process and verify"), margin(0, 6, 0, 8))
        runButton = button("Process selected images", true)
        runButton.setOnClickListener { launchProcessing() }
        content.addView(runButton, margin(0, 0, 0, 12))

        statusText = TextView(this).apply {
            text = "Ready. Select images and a preset."
            textSize = 13f
            setTextColor(Color.rgb(52, 64, 84))
            setBackgroundColor(Color.WHITE)
            setPadding(dp(13), dp(12), dp(13), dp(12))
        }
        content.addView(statusText)
        content.addView(text("Output folder: Pictures/ImgForge_Output\nInput copies: Pictures/ImgForge_Input\n\nImportant: pixel upscaling increases dimensions but does not invent missing detail. The streetwear preset preserves transparency only when it already exists in the source.", 12f, Color.rgb(102, 112, 133)), margin(0, 18, 0, 0))

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickImagesCode || resultCode != RESULT_OK || data == null) return
        val picked = mutableListOf<Uri>()
        data.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) picked.add(clip.getItemAt(i).uri)
        } ?: data.data?.let { picked.add(it) }
        selectedUris = picked.distinct()
        selectedText.text = if (selectedUris.isEmpty()) "No images selected" else "${selectedUris.size} image(s) selected"
        statusText.text = if (selectedUris.isEmpty()) "No images selected." else "Ready to copy ${selectedUris.size} image(s) into a dedicated input folder and run the selected preset."
    }

    private fun launchProcessing() {
        if (busy) return
        if (selectedUris.isEmpty()) {
            Toast.makeText(this, "Choose at least one image first", Toast.LENGTH_SHORT).show()
            return
        }
        val termux = Intent().setClassName("com.termux", "com.termux.app.RunCommandService")
        termux.action = "com.termux.RUN_COMMAND"
        val preset = presets[presetSpinner.selectedItemPosition]
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val inputRelative = "Pictures/ImgForge_Input/Batch_$stamp"
        val outputRelative = "Pictures/ImgForge_Output/Batch_$stamp"
        val inputPath = "/storage/emulated/0/$inputRelative"
        val outputPath = "/storage/emulated/0/$outputRelative"
        val reportPath = "$outputPath/report.json"

        busy = true
        runButton.isEnabled = false
        statusText.text = "Copying ${selectedUris.size} image(s) to shared storage…"
        Thread {
            try {
                val copied = copySelectedImages(inputRelative)
                if (copied == 0) throw IllegalStateException("No selected images could be copied.")
                val args = mutableListOf<String>(inputPath)
                if (preset.longEdge != null) {
                    args.addAll(listOf("--long-edge", preset.longEdge.toString()))
                }
                args.addAll(listOf("--format", preset.format, "--filter", preset.filter, "--jobs", "1", "--recursive", "--report", reportPath, "--timeout", preset.timeout.toString()))
                if (preset.dpi != null) args.addAll(listOf("--dpi", preset.dpi.toString()))
                if (preset.quality != null) args.addAll(listOf("--quality", preset.quality.toString()))
                if (preset.flatten) args.add("--flatten")
                if (preset.background != null) args.addAll(listOf("--background", preset.background))
                args.addAll(listOf("-o", outputPath))

                termux.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/imgforge")
                termux.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", args.toTypedArray())
                termux.putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
                termux.putExtra("com.termux.RUN_COMMAND_BACKGROUND", false)
                termux.putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0")
                termux.putExtra("com.termux.RUN_COMMAND_COMMAND_LABEL", "ImgForge: ${preset.title}")
                termux.putExtra("com.termux.RUN_COMMAND_COMMAND_DESCRIPTION", "Process ${copied} image(s) using the selected ImgForge preset.")
                runOnUiThread {
                    try {
                        startService(termux)
                        statusText.text = "Started ImgForge in Termux.\nPreset: ${preset.title}\nImages copied: $copied\nOutput: $outputPath\nReport: $reportPath\n\nWatch the Termux session for per-file results."
                    } catch (e: Exception) {
                        statusText.text = "Could not start Termux. Check that Termux is installed, ImgForge is installed, RUN_COMMAND permission is granted to ImgForge, and allow-external-apps is enabled.\n\nDetails: ${e.message}"
                    } finally {
                        busy = false
                        runButton.isEnabled = true
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusText.text = "Preparation failed: ${e.message}"
                    busy = false
                    runButton.isEnabled = true
                }
            }
        }.start()
    }

    private fun copySelectedImages(relativeDir: String): Int {
        var count = 0
        selectedUris.forEachIndexed { index, uri ->
            val displayName = queryDisplayName(uri) ?: "image_${index + 1}.img"
            val safeName = displayName.replace(Regex("[^A-Za-z0-9._ -]"), "_").trim().ifBlank { "image_${index + 1}.img" }
            val prefixedName = String.format(Locale.US, "%03d_%s", index + 1, safeName)
            val mime = contentResolver.getType(uri) ?: "application/octet-stream"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, prefixedName)
                put(MediaStore.Images.Media.MIME_TYPE, mime)
                put(MediaStore.Images.Media.RELATIVE_PATH, "$relativeDir/")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val dest = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return@forEachIndexed
            try {
                val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot read $displayName")
                input.use { source ->
                    val output = contentResolver.openOutputStream(dest) ?: throw IllegalStateException("Cannot write $prefixedName")
                    output.use { target -> source.copyTo(target) }
                }
                val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                contentResolver.update(dest, done, null, null)
                count++
            } catch (e: Exception) {
                contentResolver.delete(dest, null, null)
                throw e
            }
        }
        return count
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) return cursor.getString(idx)
            }
        }
        return null
    }

    private fun text(value: String, size: Float, color: Int) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
    }

    private fun section(value: String) = TextView(this).apply {
        text = value
        textSize = 17f
        setTextColor(Color.rgb(16, 24, 40))
        setTypeface(null, android.graphics.Typeface.BOLD)
    }

    private fun button(label: String, primary: Boolean) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(if (primary) Color.WHITE else Color.rgb(16, 24, 40))
        setBackgroundColor(if (primary) Color.rgb(36, 87, 214) else Color.WHITE)
        minimumHeight = dp(48)
    }

    private fun margin(left: Int, top: Int, right: Int, bottom: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(dp(left), dp(top), dp(right), dp(bottom)) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
