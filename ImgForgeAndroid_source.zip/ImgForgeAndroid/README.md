# ImgForge Android (source project)

A native Android UI for choosing image files and predefined processing profiles, using the separately installed ImgForge 2.0 engine in Termux. This is a source project, not a compiled APK; it does not include the ImgForge engine.

## Profiles included

- Fine Art Print · 8K PNG: longest edge 8000, PNG, 300 DPI metadata.
- Fine Art Master · 16K TIFF: longest edge 16000, TIFF, 300 DPI metadata, longer timeout.
- Transparent Streetwear PNG: longest edge 6000, PNG; preserves existing transparency but does not remove backgrounds.
- Print TIFF · Keep Dimensions: TIFF conversion without resizing, 300 DPI metadata.
- JPEG Preview: longest edge 3000, quality 95, flatten transparency onto white.
- WebP Preview: longest edge 3000, quality 92.

Originals are not modified. The app copies selected files to `Pictures/ImgForge_Input/Batch_<timestamp>` and writes outputs to `Pictures/ImgForge_Output/Batch_<timestamp>`. Batch names include milliseconds and a random suffix to avoid collisions. A failed input-copy operation rolls back the copies created for that batch.

The app reports when it hands a command to Termux; it cannot independently confirm the engine's completion or validate the report. Check the Termux session and the generated `report.json` for per-file results.

## Prerequisites on the phone

1. Install Termux from a trusted source and install Python + ImageMagick.
2. Install the ImgForge 2.0 script as `$PREFIX/bin/imgforge`.
3. Run `termux-setup-storage` and ensure Termux has storage access. On Android 8–9, ImgForge also requests Android's legacy write-storage permission when processing.
4. Configure Termux's external command permission as described below.

## Termux bridge setup

The app uses Termux's documented `com.termux.RUN_COMMAND` intent to call the fixed executable `$PREFIX/bin/imgforge` with arguments. This requires:

- Termux version supporting `RUN_COMMAND` (0.95+; results and newer extras need newer versions).
- `allow-external-apps = true` in `~/.termux/termux.properties`.
- Grant ImgForge's Android app permission **Run commands in Termux environment** under Android Settings → Apps → ImgForge → Permissions / Additional permissions.
- Grant Termux storage access. Some Android versions may require restarting Termux after changing storage permission.

Security note: enabling external commands allows authorized third-party apps to run commands in Termux. Install this app only if you trust the build, and don't grant the permission to unknown apps.

To set the Termux property from Termux, run:

```sh
mkdir -p ~/.termux
if grep -q '^allow-external-apps' ~/.termux/termux.properties 2>/dev/null; then
  sed -i 's/^allow-external-apps.*/allow-external-apps = true/' ~/.termux/termux.properties
else
  printf '\nallow-external-apps = true\n' >> ~/.termux/termux.properties
fi
```

## Build

Open this folder in Android Studio or AndroidIDE with internet access and build the `app` debug variant. The generated APK will usually be at `app/build/outputs/apk/debug/app-debug.apk`.

The project is configured with Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile/target SDK 35, minimum Android 8.0 (API 26), and version 1.1. Android 8–9 use legacy public Pictures storage; Android 10 and later use MediaStore. A local APK has not been built or tested in this environment, so compile and device validation remain necessary.

## Optional cloud build

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. After pushing this project to a GitHub repository, run the **Build ImgForge Android APK** workflow (or push to `main`/`master`). Download the `ImgForge-debug-apk` artifact from the completed workflow run. This is an unsigned debug APK intended for personal testing, not Play Store release.
